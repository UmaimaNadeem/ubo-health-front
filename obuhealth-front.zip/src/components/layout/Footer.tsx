import { Link } from "react-router-dom";
import { Youtube, Instagram, Facebook, Globe, HelpCircle, FileText } from "lucide-react";
import logoOnyxWhite from "../../assets/logo-onyx-white.webp";
import { ENQUIRY_REGIONS, WHATSAPP_URL, WHATSAPP_DISPLAY } from "../../data/contact";
import { WhatsAppIcon } from "../WhatsAppIcon";

function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
    </svg>
  );
}

const SOCIAL_LINKS = [
  { href: "https://www.youtube.com/@Onyxhealth._net", label: "YouTube", Icon: Youtube },
  { href: "https://www.instagram.com/onyx_h_ealth/", label: "Instagram", Icon: Instagram },
  { href: "https://www.tiktok.com/@onyxhealthonyx", label: "TikTok", Icon: TikTokIcon },
  {
    href: "https://www.facebook.com/profile.php?id=61593091294487",
    label: "Facebook",
    Icon: Facebook,
  },
];

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-gradient-to-br from-primary to-[#0a1733] text-primary-foreground">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-40 -top-24 h-80 w-80 rounded-full bg-accent/20 blur-[150px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 bottom-0 h-80 w-80 rounded-full bg-sky-500/10 blur-[150px]"
      />
      <div
        aria-hidden
        className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent"
      />
      {/* One column on phones (hairline rule between each), 2x2 on tablets, and a
          single row from lg where the two text columns keep a fixed width while the
          link columns size to their content; justify-between spreads the slack. */}
      <div className="relative mx-auto grid max-w-7xl grid-cols-1 gap-7 px-4 py-12 max-md:[&>div:not(:last-child)]:border-b max-md:[&>div:not(:last-child)]:border-white/10 max-md:[&>div:not(:last-child)]:pb-7 md:grid-cols-2 md:gap-10 md:py-16 lg:flex lg:flex-row lg:justify-between lg:gap-8">
        <div className="lg:w-72 lg:shrink-0">
          <img
            src={logoOnyxWhite}
            alt="ONYX Research"
            width={410}
            height={156}
            loading="lazy"
            className="h-12 w-auto"
          />
          <p className="mt-3 text-sm opacity-80">
            Premium research peptides, discreetly dispatched across Europe. For laboratory research
            only.
          </p>

          <div className="mt-5 flex items-center gap-2.5">
            {SOCIAL_LINKS.map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="group grid h-10 w-10 place-items-center rounded-xl border border-white/20 bg-white/[0.03] backdrop-blur-sm transition hover:-translate-y-0.5 hover:border-accent hover:bg-accent/10 hover:shadow-[0_0_16px_-2px] hover:shadow-accent/50"
              >
                <Icon className="h-5 w-5 opacity-80 transition group-hover:text-accent group-hover:opacity-100" />
              </a>
            ))}
          </div>
        </div>
        {/* Global enquiries: full contact block, visible on every page */}
        <div className="lg:w-72 lg:shrink-0">
          <h4 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider">
            <Globe className="h-4 w-4 shrink-0 text-accent" />
            Research Enquiries
          </h4>
          <div className="text-sm font-bold">{ENQUIRY_REGIONS.join(" • ")}</div>
          <p className="mt-2.5 text-sm leading-relaxed opacity-80">
            For laboratory research, analytical documentation, and business enquiries, contact our
            team.
          </p>

          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="group mt-4 flex items-center gap-3 rounded-xl border border-white/15 bg-white/[0.03] p-3 backdrop-blur-sm transition hover:border-[#25d366]/60 hover:bg-[#25d366]/10"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-[#25d366]/15 text-[#25d366] ring-1 ring-inset ring-[#25d366]/25 transition group-hover:bg-[#25d366] group-hover:text-white">
              <WhatsAppIcon className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block text-[10px] font-bold uppercase tracking-wider opacity-70">
                WhatsApp
              </span>
              <span className="mt-0.5 block text-sm font-black tracking-tight transition group-hover:text-[#25d366]">
                {WHATSAPP_DISPLAY}
              </span>
            </span>
          </a>

          <p className="mt-4 border-t border-white/10 pt-3 text-sm leading-relaxed opacity-80">
            Serving business enquiries across the UK, Europe &amp; Middle East.
          </p>
        </div>
        <div>
          <h4 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider">
            <HelpCircle className="h-4 w-4 shrink-0 text-accent" />
            Help
          </h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li>
              <Link to="/peptides" className="hover:text-accent">
                All Peptides
              </Link>
            </li>
            <li>
              <Link to="/peptides/blends" className="hover:text-accent">
                Blends
              </Link>
            </li>
            <li>
              <Link to="/peptides/plans" className="hover:text-accent">
                Essentials
              </Link>
            </li>
            <li>
              <Link to="/faq" className="hover:text-accent">
                FAQ
              </Link>
            </li>
            <li>
              <Link to="/check-code" className="hover:text-accent">
                Check Code
              </Link>
            </li>
            <li>
              <Link to="/payment-delivery" className="hover:text-accent">
                Payment & Delivery
              </Link>
            </li>
            <li>
              <Link to="/product-returns" className="hover:text-accent">
                Returns
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-accent">
                Contact
              </Link>
            </li>
            <li>
              <Link to="/wholesale-application" className="hover:text-accent">
                Wholesale Application
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider">
            <FileText className="h-4 w-4 shrink-0 text-accent" />
            Policies
          </h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li>
              <Link to="/privacy-policy" className="hover:text-accent">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms-conditions" className="hover:text-accent">
                Terms & Conditions
              </Link>
            </li>
            <li>
              <Link to="/refund-policy" className="hover:text-accent">
                Refund Policy
              </Link>
            </li>
            <li>
              <Link to="/shipping-policy" className="hover:text-accent">
                Shipping &amp; Delivery Policy
              </Link>
            </li>
            <li>
              <Link to="/cookies-policy" className="hover:text-accent">
                Cookies Policy
              </Link>
            </li>
            <li>
              <Link to="/accessibility-policy" className="hover:text-accent">
                Accessibility Policy
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-white/10 px-4 py-6">
        <div className="mx-auto max-w-5xl space-y-2 text-center text-xs leading-relaxed opacity-60 md:text-[13px]">
          <p>
            Disclaimer: Statements on this website have not been evaluated by any regulatory
            authority. All products are supplied strictly for laboratory research purposes and are
            not intended for human or veterinary use. Nothing on this site is intended to diagnose,
            treat, cure, or prevent any disease.
          </p>
          <p>
            Product information is compiled from a range of studies and analyses gathered over time
            and is provided for research reference only, it is not intended to support the
            diagnosis, treatment, or prevention of any disease.
          </p>
          <p>
            This site is protected against automated abuse by Cloudflare, in accordance with the{" "}
            <a
              href="https://www.cloudflare.com/privacypolicy/"
              target="_blank"
              rel="noopener noreferrer"
              className="underline hover:text-accent"
            >
              Cloudflare Privacy Policy
            </a>
            .
          </p>
        </div>
      </div>
      <div className="border-t border-white/10 px-4 py-4 text-center text-xs leading-relaxed opacity-70">
        © {new Date().getFullYear()} ONYX Research. All rights reserved. Reproduction of any content
        without prior written consent is strictly prohibited.
      </div>
    </footer>
  );
}
