import { useState, useRef, useEffect, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ShoppingCart,
  Heart,
  User,
  Menu,
  X,
  Search,
  ChevronDown,
  Truck,
  Users,
  FlaskConical,
  ShieldCheck,
} from "lucide-react";
import { usePlans, useProducts } from "../../lib/api";
import { useAuth, useCart, useWishlist } from "../../context/contexts";
import logoOnyx from "../../assets/logo-onyx.webp";
import LanguageSwitcher from "../LanguageSwitcher";

type NavItem = {
  to: string;
  label: string;
  sub?: { to: string; label: string }[];
};

const NAV: NavItem[] = [
  { to: "/peptides", label: "Research Peptides" },
  { to: "/peptide-plans", label: "Peptide Plans" },
  { to: "/what-are-peptides", label: "What are Peptides?" },
  { to: "/check-code", label: "Check Code" },
  { to: "/payment-delivery", label: "Payment & Delivery" },
  { to: "/wholesale-application", label: "Partner With Us (B2B)" },
  { to: "/contact", label: "Contact" },
];

// Shared desktop nav link sizing — tightened at lg so all eight labels fit on one row.
const navLinkClass =
  "whitespace-nowrap px-1 py-2 text-[12px] font-medium transition hover:text-accent xl:px-2.5 xl:text-sm";

function UkFlag() {
  return (
    <span className="inline-flex h-3 w-5 shrink-0 overflow-hidden rounded-[2px] ring-1 ring-white/25">
      <svg
        viewBox="0 0 60 30"
        className="h-full w-full"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden
      >
        <clipPath id="uk-flag-clip">
          <path d="M0,0 v30 h60 v-30 z" />
        </clipPath>
        <clipPath id="uk-flag-diag">
          <path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z" />
        </clipPath>
        <g clipPath="url(#uk-flag-clip)">
          <path d="M0,0 v30 h60 v-30 z" fill="#012169" />
          <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6" />
          <path
            d="M0,0 L60,30 M60,0 L0,30"
            clipPath="url(#uk-flag-diag)"
            stroke="#C8102E"
            strokeWidth="4"
          />
          <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10" />
          <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6" />
        </g>
      </svg>
    </span>
  );
}

const iconClass = "h-3.5 w-3.5 shrink-0 text-accent";
const TICKER_MESSAGES = [
  { icon: <UkFlag />, text: "Manufactured in the EU & UK" },
  { icon: <Truck className={iconClass} />, text: "Fast Secure Shipping" },
  { icon: <Users className={iconClass} />, text: "Trusted by 1000s of customers" },
  { icon: <FlaskConical className={iconClass} />, text: "GMP-aligned laboratory" },
  { icon: <ShieldCheck className={iconClass} />, text: "Stabilized formula" },
];

function TopBarTicker() {
  const [index, setIndex] = useState(0);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    const id = setInterval(() => {
      setIndex((prev) => (prev + 1) % TICKER_MESSAGES.length);
    }, 4500);
    return () => clearInterval(id);
  }, []);

  const { icon, text } = TICKER_MESSAGES[index];

  return (
    <div className="relative h-5 min-w-0 flex-1 overflow-hidden">
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={index}
          initial={prefersReducedMotion ? { opacity: 0 } : { y: "120%", opacity: 0 }}
          animate={{ y: "0%", opacity: 1 }}
          exit={prefersReducedMotion ? { opacity: 0 } : { y: "-120%", opacity: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0 flex items-center gap-2"
        >
          {icon}
          <span className="truncate text-xs font-medium tracking-wide">{text}</span>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function AccountMenu({ loggedIn }: { loggedIn: boolean }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isB2b = user?.role === "retailer" || user?.role === "wholesaler";
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, right: 0 });
  const btnRef = useRef<HTMLButtonElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const reposition = () => {
    const r = btnRef.current?.getBoundingClientRect();
    if (r) setPos({ top: r.bottom, right: window.innerWidth - r.right });
  };

  const openIt = () => {
    if (!loggedIn) return;
    if (timer.current) clearTimeout(timer.current);
    reposition();
    setOpen(true);
  };

  const closeIt = () => {
    if (!loggedIn) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setOpen(false), 150);
  };

  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    window.addEventListener("scroll", close, true);
    window.addEventListener("resize", close);
    return () => {
      window.removeEventListener("scroll", close, true);
      window.removeEventListener("resize", close);
    };
  }, [open]);

  if (!loggedIn) {
    return (
      <Link
        to="/login"
        className="relative grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/10"
        aria-label="Consumer Login"
      >
        <User className="h-5 w-5" />
      </Link>
    );
  }

  return (
    <>
      <button
        ref={btnRef}
        onMouseEnter={openIt}
        onMouseLeave={closeIt}
        onClick={() => (open ? setOpen(false) : openIt())}
        className="relative grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/10"
        aria-label="Account"
        aria-haspopup="true"
        aria-expanded={open}
      >
        <User className="h-5 w-5" />
      </button>
      {open &&
        createPortal(
          <div
            style={{ position: "fixed", top: pos.top, right: pos.right }}
            className="z-[100] pt-2"
            onMouseEnter={openIt}
            onMouseLeave={closeIt}
          >
            <div className="min-w-48 rounded-xl border bg-popover p-2 shadow-xl">
              <Link
                to="/profile"
                onClick={() => setOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm font-medium text-popover-foreground transition hover:bg-secondary hover:text-accent"
              >
                My Profile
              </Link>
              {isB2b && (
                <Link
                  to="/quick-order"
                  onClick={() => setOpen(false)}
                  className="block rounded-lg px-3 py-2 text-sm font-medium text-popover-foreground transition hover:bg-secondary hover:text-accent"
                >
                  Quick Order
                </Link>
              )}
              <button
                onClick={async () => {
                  setOpen(false);
                  await logout();
                  navigate("/");
                }}
                className="block w-full rounded-lg px-3 py-2 text-left text-sm font-medium text-popover-foreground transition hover:bg-secondary hover:text-accent"
              >
                Log out
              </button>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}

function SearchMenu({ inNav = false }: { inNav?: boolean }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  // Panel is centred on the icon; `shift` nudges it back in only when that would
  // push it past a viewport edge (the icon sits near the right edge on desktop).
  const [shift, setShift] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const { data: allProducts = [] } = useProducts();

  const query = search.trim();
  const suggestions =
    query.length >= 2
      ? allProducts.filter((p) => p.name.toLowerCase().includes(query.toLowerCase())).slice(0, 6)
      : [];

  useLayoutEffect(() => {
    // Only the in-nav panel is centred on its icon; the mobile one is edge-anchored.
    if (!open || !inNav) return;
    const clamp = () => {
      const panel = panelRef.current;
      const btn = btnRef.current;
      if (!panel || !btn) return;
      const margin = 8;
      const b = btn.getBoundingClientRect();
      const w = panel.offsetWidth;
      // clientWidth, not innerWidth: on mobile the layout viewport grows to cover
      // an overflowing panel, so innerWidth would report the widened page and the
      // clamp would keep concluding the panel already fits.
      const viewport = document.documentElement.clientWidth;
      const centredLeft = b.left + b.width / 2 - w / 2;
      const maxLeft = viewport - margin - w;
      if (centredLeft > maxLeft) setShift(maxLeft - centredLeft);
      else if (centredLeft < margin) setShift(margin - centredLeft);
      else setShift(0);
    };
    clamp();
    window.addEventListener("resize", clamp);
    return () => window.removeEventListener("resize", clamp);
  }, [open, inNav]);

  useEffect(() => {
    if (!open) return;
    inputRef.current?.focus();
    function handleClick(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    }
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, [open]);

  const go = (to: string) => {
    setOpen(false);
    setSearch("");
    navigate(to);
  };

  return (
    // Off nav (mobile), the panel spans the header row rather than this button,
    // so the wrapper deliberately stays unpositioned.
    <div ref={wrapRef} className={inNav ? "relative" : ""}>
      <button
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        className={
          inNav
            ? // Match the text links' rhythm so the icon reads as part of the same list
              `flex items-center ${navLinkClass} ${open ? "text-accent" : ""}`
            : "grid h-10 w-10 shrink-0 place-items-center rounded-full transition hover:bg-secondary"
        }
        aria-label="Search"
        aria-expanded={open}
      >
        <Search className={inNav ? "h-4 w-4" : "h-5 w-5"} />
      </button>
      {open && (
        <div
          ref={panelRef}
          style={inNav ? { transform: `translateX(calc(-50% + ${shift}px))` } : undefined}
          className={
            inNav
              ? "absolute left-1/2 top-full z-50 w-[min(92vw,32rem)] pt-2"
              : "absolute inset-x-2 top-full z-50 pt-2"
          }
        >
          <div className="overflow-hidden rounded-2xl border bg-popover text-popover-foreground shadow-2xl">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!query) return;
                go(`/peptides?q=${encodeURIComponent(query)}`);
              }}
              className="relative border-b"
            >
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                ref={inputRef}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search peptides…"
                className="w-full bg-transparent py-3.5 pl-11 pr-4 text-sm outline-none"
              />
            </form>
            {suggestions.map((p) => (
              <button
                key={p.id}
                onMouseDown={() =>
                  go(p.category === "programs" ? `/peptide-plans/${p.slug}` : `/product/${p.slug}`)
                }
                className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm transition hover:bg-secondary"
              >
                <Search className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span title={p.name} className="min-w-0 flex-1 font-medium">
                  {p.name}
                </span>
                <span className="ml-auto shrink-0 text-xs text-muted-foreground">
                  {(p.variants?.length ?? 0) > 1 ? "From " : ""}£{p.price}
                </span>
              </button>
            ))}
            {query.length >= 2 && (
              <button
                onMouseDown={() => go(`/peptides?q=${encodeURIComponent(query)}`)}
                className="flex w-full items-center gap-2 border-t px-4 py-2.5 text-left text-sm font-semibold text-accent transition hover:bg-secondary"
              >
                See all results for "{query}" →
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function NavDropdown({ item }: { item: NavItem }) {
  const [open, setOpen] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const openIt = () => {
    if (timer.current) clearTimeout(timer.current);
    setOpen(true);
  };
  const closeIt = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setOpen(false), 150);
  };
  return (
    <div className="relative" onMouseEnter={openIt} onMouseLeave={closeIt}>
      <NavLink
        to={item.to}
        className={({ isActive }) =>
          `flex items-center gap-1 ${navLinkClass} ${isActive ? "text-accent" : ""}`
        }
      >
        {item.label} <ChevronDown className="h-3 w-3" />
      </NavLink>
      {open && (
        <div className="absolute left-1/2 top-full z-50 -translate-x-1/2 pt-2">
          <div className="min-w-64 rounded-xl border bg-popover p-2 shadow-xl">
            {item.sub?.map((s) => (
              <Link
                key={s.to}
                to={s.to}
                onClick={() => setOpen(false)}
                className="block rounded-lg px-3 py-2 text-sm font-medium transition hover:bg-secondary hover:text-accent"
              >
                {s.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function Header() {
  const [open, setOpen] = useState(false);
  const [openSection, setOpenSection] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [headerHeight, setHeaderHeight] = useState(0);
  const headerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!open) {
      setOpenSection(null);
      return;
    }
    const measure = () => setHeaderHeight(headerRef.current?.offsetHeight ?? 0);
    measure();
    window.addEventListener("resize", measure);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("resize", measure);
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    function onScroll() {
      const y = window.scrollY;
      // Hysteresis: collapse past 64px, only re-expand back near the very top.
      // The deadzone (10–64px) prevents the top bar from flickering/vibrating.
      setScrolled((prev) => {
        if (!prev && y > 64) return true;
        if (prev && y < 10) return false;
        return prev;
      });
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const cart = useCart();
  const wish = useWishlist();
  const auth = useAuth();

  const { data: plans = [] } = usePlans();
  const nav = NAV.map((n) =>
    n.to === "/peptide-plans"
      ? {
          ...n,
          sub: plans.map((p) => ({ to: `/peptide-plans/${p.slug}`, label: p.name })),
        }
      : n,
  );

  return (
    <header ref={headerRef} className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur">
      {/* Top bar: promo text (left) + account icons (right) — stays visible with the navbar */}
      <div className="bg-primary text-primary-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-1.5">
          <TopBarTicker />
          <div className="flex shrink-0 items-center gap-0.5">
            <LanguageSwitcher className="hidden lg:block" />
            <Link
              to="/b2b-login"
              className="hidden whitespace-nowrap px-2.5 py-2 text-xs font-semibold transition hover:text-accent lg:inline-flex"
            >
              Trader Login
            </Link>
            <AccountMenu loggedIn={Boolean(auth.user)} />
            <Link
              to="/wishlist"
              className="relative grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/10"
              aria-label="Wishlist"
            >
              <Heart className="h-5 w-5" />
              {wish.count > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground">
                  {wish.count}
                </span>
              )}
            </Link>
            <Link
              to="/cart"
              className="relative grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/10"
              aria-label="Cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {cart.count > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground">
                  {cart.count}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>

      {/* Main row: logo (left) · nav links (center) · search + mobile menu toggle (right) */}
      <div className="relative mx-auto flex max-w-7xl items-center gap-2 px-2 py-2 lg:px-3">
        <Link to="/" className="flex shrink-0 items-center gap-2" aria-label="ONYX Research home">
          <img
            src={logoOnyx}
            alt="ONYX Research"
            width={406}
            height={174}
            className={`w-auto transition-all duration-300 ${scrolled ? "h-10 md:h-11" : "h-12 md:h-14"}`}
          />
        </Link>

        {/* Center nav (desktop) */}
        <nav className="relative hidden flex-1 items-center justify-center lg:flex">
          {nav.map((n, i) => (
            <div key={n.to} className="flex items-center">
              {i > 0 && <span aria-hidden className="h-4 w-px bg-border" />}
              {n.sub ? (
                <NavDropdown item={n} />
              ) : (
                <NavLink
                  to={n.to}
                  className={({ isActive }) => `${navLinkClass} ${isActive ? "text-accent" : ""}`}
                >
                  {n.label}
                </NavLink>
              )}
            </div>
          ))}
          {/* Search is the last item of the same list — divider included */}
          <div className="flex items-center">
            <span aria-hidden className="h-4 w-px bg-border" />
            <SearchMenu inNav />
          </div>
        </nav>

        {/* Mobile: search + menu toggle (desktop search lives inside the nav) */}
        <div className="ml-auto flex items-center lg:hidden">
          <SearchMenu />
          <button
            onClick={() => setOpen(!open)}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full hover:bg-secondary"
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div
          className="fixed inset-x-0 z-40 overflow-y-auto border-t bg-background lg:hidden"
          style={{ top: headerHeight, height: `calc(100dvh - ${headerHeight}px)` }}
        >
          <div className="flex flex-col pb-8">
            {nav.map((n) => {
              const hasChildren = Boolean(n.sub);
              const isSectionOpen = openSection === n.to;
              return (
                <div key={n.to}>
                  <div className="flex items-center border-b">
                    <NavLink
                      to={n.to}
                      onClick={() => {
                        if (!hasChildren) setOpen(false);
                      }}
                      className="flex flex-1 items-center gap-2 px-4 py-3 text-sm font-medium"
                    >
                      {n.label}
                    </NavLink>
                    {hasChildren && (
                      <button
                        onClick={() => setOpenSection(isSectionOpen ? null : n.to)}
                        className="grid h-11 w-11 shrink-0 place-items-center"
                        aria-label={`Toggle ${n.label} submenu`}
                        aria-expanded={isSectionOpen}
                      >
                        <ChevronDown
                          className={`h-4 w-4 transition-transform ${isSectionOpen ? "rotate-180" : ""}`}
                        />
                      </button>
                    )}
                  </div>
                  {hasChildren &&
                    isSectionOpen &&
                    n.sub?.map((s) => (
                      <NavLink
                        key={s.to}
                        to={s.to}
                        onClick={() => setOpen(false)}
                        className="block border-b bg-secondary/40 px-8 py-2.5 text-sm text-muted-foreground"
                      >
                        {s.label}
                      </NavLink>
                    ))}
                </div>
              );
            })}
            <div className="flex items-center justify-between border-b px-4 py-3">
              <span className="text-sm font-medium">Language</span>
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
