import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  BadgeCheck,
  ArrowRight,
  Handshake,
  Headset,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  FlaskConical,
  Microscope,
  Dna,
  Atom,
  Thermometer,
  Settings2,
  Stethoscope,
  UserCheck,
  ShieldCheck,
  Lock,
} from "lucide-react";
import { HERO_VIDEO_PREMIUM } from "../data/data";
import { useProducts, type Product } from "../lib/api";
import { ProductThumb } from "../components/ProductThumb";
import { DualChamberPenCard } from "../components/DualChamberPenCard";
import { TrustBar } from "../components/TrustBar";
import { Seo } from "../components/Seo";
import researchHome from "../assets/researchhome.webp";
import qualityTestingImage from "../assets/w-certificate.webp";
import doctorImage from "../assets/doctor.webp";

const INSIDE_LAB_VIDEO_ID = "W1-7GmGogEg";

const DOCTOR_POINTS = [
  { icon: UserCheck, title: "Independent doctor review" },
  { icon: ShieldCheck, title: "Licensed medical professional" },
  { icon: ClipboardCheck, title: "Medical suitability screening" },
  { icon: Lock, title: "Confidential consultation" },
];

const TABS = ["Bestsellers", "Latest", "Specials"] as const;
type Tab = (typeof TABS)[number];

function getTabProducts(tab: Tab, products: Product[]) {
  if (tab === "Bestsellers") {
    // Curated lead-in, then the rest of the bestsellers
    const featured = ["retatrutide", "nad-plus-100mg", "bpc-157-tb-500-blend", "epithalon-20mg"];
    const excluded = new Set(["5-amino-1mq-100mg", "hgh-fragment-176-191-5mg"]);
    const bestsellers = products.filter(
      (p) => p.badges?.includes("bestseller") && !excluded.has(p.slug),
    );
    const lead = featured
      .map((s) => bestsellers.find((p) => p.slug === s))
      .filter((p) => p !== undefined);
    const rest = bestsellers.filter((p) => !featured.includes(p.slug));
    return [...lead, ...rest];
  }
  if (tab === "Latest") return products.filter((p) => p.badges?.includes("new"));
  if (tab === "Specials") return products.filter((p) => p.badges?.includes("sale"));
  return products;
}

const RESEARCH_AREAS = [
  {
    icon: Dna,
    title: "Peptide Characterisation",
    body: "Laboratory investigation of peptide identity, composition and analytical characteristics.",
  },
  {
    icon: Atom,
    title: "Molecular Research",
    body: "Research involving peptide structure, molecular properties and interactions.",
  },
  {
    icon: Microscope,
    title: "Analytical Research",
    body: "Laboratory analysis of peptide materials using established analytical methods.",
  },
  {
    icon: Thermometer,
    title: "Stability Research",
    body: "Investigation of material stability and characteristics under controlled laboratory conditions.",
  },
  {
    icon: FlaskConical,
    title: "Biochemical Research",
    body: "Laboratory investigation of peptide-related biochemical properties and processes.",
  },
  {
    icon: Settings2,
    title: "Method Development",
    body: "Research supporting analytical procedures and laboratory testing workflows.",
  },
];

const EASE = [0.22, 1, 0.36, 1] as const;
const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: EASE } },
};
const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } },
};

function SkeletonCard({ className = "" }: { className?: string }) {
  return <div className={`aspect-square animate-pulse rounded-xl bg-secondary ${className}`} />;
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("Bestsellers");
  const { data: allProducts = [], isLoading: allProductsLoading } = useProducts();
  const { data: penProducts = [], isLoading: penProductsLoading } = useProducts({
    category: "dual-chamber-peptide-pens",
  });
  const tabProducts = getTabProducts(activeTab, allProducts).slice(0, 4);

  const insideLabRef = useRef<HTMLDivElement | null>(null);
  const [showInsideLabVideo, setShowInsideLabVideo] = useState(false);
  useEffect(() => {
    const el = insideLabRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShowInsideLabVideo(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const penViewportRef = useRef<HTMLDivElement | null>(null);
  const penTrackRef = useRef<HTMLDivElement | null>(null);
  const [penOffset, setPenOffset] = useState(0);

  const penVisibleWidth = useCallback(() => {
    const viewport = penViewportRef.current;
    if (!viewport) return 0;
    const style = getComputedStyle(viewport);
    const padLeft = parseFloat(style.paddingLeft) || 0;
    const padRight = parseFloat(style.paddingRight) || 0;
    return viewport.clientWidth - padLeft - padRight;
  }, []);

  const penMaxOffset = useCallback(() => {
    const track = penTrackRef.current;
    if (!track) return 0;
    return Math.max(0, track.scrollWidth - penVisibleWidth());
  }, [penVisibleWidth]);

  const scrollPenSlider = (dir: 1 | -1) => {
    const visibleWidth = penVisibleWidth();
    setPenOffset((prev) => Math.min(Math.max(prev + dir * visibleWidth, 0), penMaxOffset()));
  };

  useEffect(() => {
    const handleResize = () => setPenOffset((prev) => Math.min(prev, penMaxOffset()));
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [penMaxOffset]);

  return (
    <div>
      <Seo
        title="ONYX Research | Laboratory Research Materials"
        description="Research-grade laboratory material with batch-level analytical information. Supplied exclusively for legitimate scientific research."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "ONYX Research",
          description:
            "Supplier of research-grade laboratory materials with batch-level analytical documentation for legitimate scientific research.",
        }}
      />
      {/* Hero */}
      <section className="relative flex min-h-[calc(100svh-6.5rem)] items-center overflow-hidden bg-[#050a1a] text-primary-foreground lg:min-h-[calc(100svh-9rem)]">
        <video
          src={HERO_VIDEO_PREMIUM}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          className="absolute inset-0 h-full w-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-[#050a1a]/72" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050a1a]/90 via-[#050a1a]/35 to-[#050a1a]/50" />
        <motion.div
          aria-hidden
          className="pointer-events-none absolute -left-32 top-1/4 h-96 w-96 rounded-full bg-accent/30 blur-[120px]"
          animate={{ x: [0, 30, 0], y: [0, -20, 0] }}
          transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          aria-hidden
          className="pointer-events-none absolute -right-20 bottom-0 h-80 w-80 rounded-full bg-accent/20 blur-[140px]"
          animate={{ x: [0, -25, 0], y: [0, 15, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
        <div className="relative mx-auto flex w-full max-w-3xl flex-col items-center text-center px-4 pb-7 pt-3">
          <motion.div
            variants={stagger}
            initial="hidden"
            animate="show"
            className="flex flex-col items-center"
          >
            <motion.span
              variants={fadeUp}
              className="mb-4 inline-flex w-fit items-center text-4xl font-black uppercase text-white md:text-5xl"
            >
              B2B
            </motion.span>
            <motion.span
              variants={fadeUp}
              className="mb-5 inline-flex w-fit items-center text-xs font-semibold uppercase tracking-[0.35em] text-white/60"
            >
              Supplied Direct from the Lab
            </motion.span>
            <motion.span
              variants={fadeUp}
              className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-accent backdrop-blur-sm"
            >
              Research-grade peptides
            </motion.span>
            <motion.h1
              variants={fadeUp}
              className="text-3xl font-black leading-[1.15] tracking-tight md:text-5xl lg:text-6xl"
            >
              Engineered for Research.{" "}
              <span className="bg-gradient-to-r from-accent via-sky-300 to-accent bg-clip-text text-transparent">
                Precision You Can Trust.
              </span>
            </motion.h1>
            <motion.p
              variants={fadeUp}
              className="mt-6 max-w-xl text-base leading-relaxed opacity-80 md:text-lg"
            >
              Research-grade materials, independently tested for identity and purity, intended
              exclusively for laboratory research.
            </motion.p>
            <motion.div variants={fadeUp} className="mt-7 flex flex-wrap justify-center gap-3">
              <Link
                to="/peptides"
                className="group inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground shadow-lg shadow-accent/30 transition hover:scale-[1.02] hover:shadow-accent/50"
              >
                Explore Research Materials
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/what-are-peptides"
                className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-7 py-3.5 text-sm font-bold backdrop-blur-sm transition hover:border-white/50 hover:bg-white/10"
              >
                Learn the science
              </Link>
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          className="pointer-events-none absolute bottom-6 left-1/2 hidden -translate-x-1/2 text-[10px] uppercase tracking-[0.4em] opacity-50 md:block"
          animate={{ y: [0, 8, 0], opacity: [0.4, 0.85, 0.4] }}
          transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
        >
          Scroll to explore
        </motion.div>
      </section>

      <TrustBar />

      {/* Inside the lab */}
      <section className="border-b bg-secondary/40">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-8 pt-4 sm:py-8 md:grid-cols-[1.55fr_1fr] md:py-12">
          <div
            ref={insideLabRef}
            className="aspect-video w-full overflow-hidden rounded-xl border bg-black shadow-lg"
          >
            {showInsideLabVideo && (
              <iframe
                src={`https://www.youtube.com/embed/${INSIDE_LAB_VIDEO_ID}?autoplay=1&mute=1&playsinline=1&rel=0`}
                title="Inside the ONYX laboratory"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="h-full w-full"
              />
            )}
          </div>
          <div>
            <span className="mb-3 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent">
              Inside the ONYX laboratory
            </span>
            <h2 className="mt-3 text-3xl font-black leading-tight md:text-4xl">
              The science and process behind every <span className="text-accent">ONYX</span>{" "}
              product.
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground md:text-base">
              Complete transparency into the technologies, processes, and controls behind every
              product we create.
            </p>
            <div className="mt-6 flex items-start gap-3 border-t pt-6">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-background text-accent">
                <ClipboardCheck className="h-5 w-5" />
              </span>
              <div>
                <h3 className="text-sm font-bold">Analytical control</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  Verification of key parameters through HPLC and LC-MS analysis.
                </p>
              </div>
            </div>
            <Link
              to="/peptides"
              className="group mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90"
            >
              View Research Materials
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
        <div>
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-10 gap-y-3 px-4 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground max-[450px]:justify-start">
            {["High-tech equipment", "Controlled production", "Strict quality control"].map(
              (item) => (
                <span key={item} className="flex items-center gap-2">
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-accent/15 text-accent">
                    <BadgeCheck className="h-3.5 w-3.5" />
                  </span>
                  {item}
                </span>
              ),
            )}
          </div>
        </div>
        <p className="border-t px-4 py-3 text-center text-xs text-muted-foreground">
          For laboratory standards and research purposes only.
        </p>
      </section>

      {/* Dual-Chamber Peptide Pens */}
      {(penProductsLoading || penProducts.length > 0) && (
        <section className="overflow-hidden bg-background py-12">
          <div className="mx-auto max-w-[90rem] px-4">
            <h2 className="mb-4 text-3xl font-black md:text-4xl">Research Materials</h2>
            <p className="max-w-2xl text-sm text-muted-foreground md:text-base">
              Explore ONYX research materials with batch level analytical documentation and
              laboratory focused specifications.
            </p>
          </div>

          <div className="mx-auto grid max-w-[90rem] grid-cols-2 gap-2 px-2 pb-4 pt-2 md:hidden">
            {penProductsLoading
              ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
              : penProducts.map((p, i) => {
                  const isLastOdd = penProducts.length % 2 === 1 && i === penProducts.length - 1;
                  return (
                    <div
                      key={p.id}
                      className={
                        isLastOdd ? "col-span-2 w-full max-w-[calc(50%-0.25rem)]" : undefined
                      }
                    >
                      <DualChamberPenCard product={p} />
                    </div>
                  );
                })}
          </div>

          <div
            ref={penViewportRef}
            className="mx-auto hidden max-w-[90rem] overflow-hidden px-4 pb-4 pt-2 md:block"
          >
            <motion.div
              ref={penTrackRef}
              className="flex gap-3"
              animate={{ x: -penOffset }}
              transition={{ duration: 0.9, ease: EASE }}
            >
              {penProductsLoading
                ? Array.from({ length: 4 }).map((_, i) => (
                    <SkeletonCard
                      key={i}
                      className="shrink-0 md:w-[calc((100%_-_0.75rem)/2)] lg:w-[calc((100%_-_1.5rem)/3)] xl:w-[calc((100%_-_2.25rem)/4)]"
                    />
                  ))
                : penProducts.map((p) => (
                    <motion.div
                      key={p.id}
                      whileHover={{ y: -2 }}
                      transition={{ duration: 0.4, ease: "easeOut" }}
                      className="shrink-0 md:w-[calc((100%_-_0.75rem)/2)] lg:w-[calc((100%_-_1.5rem)/3)] xl:w-[calc((100%_-_2.25rem)/4)]"
                    >
                      <DualChamberPenCard product={p} />
                    </motion.div>
                  ))}
            </motion.div>
          </div>

          <div className="mx-auto hidden max-w-[90rem] justify-center gap-2 px-4 md:flex">
            <button
              type="button"
              onClick={() => scrollPenSlider(-1)}
              aria-label="Scroll left"
              className="grid h-10 w-10 cursor-pointer place-items-center rounded-full border transition hover:border-accent hover:text-accent"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scrollPenSlider(1)}
              aria-label="Scroll right"
              className="grid h-10 w-10 cursor-pointer place-items-center rounded-full border transition hover:border-accent hover:text-accent"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </section>
      )}

      {/* Tabbed products */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
          <div className="flex gap-1 rounded-xl border bg-secondary p-1">
            {TABS.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`rounded-lg px-5 py-2 text-sm font-semibold transition ${
                  activeTab === tab
                    ? "bg-primary text-primary-foreground shadow"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
          <Link
            to="/peptides"
            className="group inline-flex items-center gap-1 text-base font-semibold text-accent transition-colors hover:text-primary"
          >
            View all
            <span className="inline-block transition-transform group-hover:translate-x-1">→</span>
          </Link>
        </div>
        {allProductsLoading ? (
          <div className="grid grid-cols-2 gap-2 md:grid-cols-3 md:gap-4 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : tabProducts.length > 0 ? (
          <motion.div
            key={activeTab}
            variants={stagger}
            initial="hidden"
            animate="show"
            className="grid grid-cols-2 gap-2 md:grid-cols-3 md:gap-4 lg:grid-cols-4"
          >
            {tabProducts.map((p) => (
              <motion.div key={p.id} variants={fadeUp} className="h-full">
                <ProductThumb product={p} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <p className="py-12 text-center text-muted-foreground">
            No products in this category yet.
          </p>
        )}
        <div className="mt-8 rounded-xl border bg-secondary p-4 text-xs leading-relaxed text-muted-foreground">
          <p className="mb-1 font-bold uppercase tracking-wider text-foreground">Research Use Only</p>
          <p>
            All ONYX materials are supplied exclusively for legitimate laboratory and scientific
            research. They are not intended for human or veterinary use, diagnosis, treatment, or
            therapeutic application.
          </p>
        </div>
      </section>

      {/* Doctor consultation */}
      {/* <section className="bg-secondary">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 md:grid-cols-2 lg:gap-16">
          <div>
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent">
              <Stethoscope className="h-3.5 w-3.5" />
              Independent Medical Guidance
            </span>
            <h2 className="max-w-lg text-3xl font-black leading-tight text-foreground md:text-4xl lg:text-5xl">
              Consult with an Independent Doctor
            </h2>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-muted-foreground">
              Schedule a consultation with an independent doctor to assess your medical suitability,
              health history, medications, risk factors, contraindications and personal goals.
            </p>
            <p className="mt-3 max-w-lg text-base leading-relaxed text-muted-foreground">
              The doctor works independently. ONYX does not diagnose, prescribe, treat or approve,
              and does not guarantee product access, prescriptions, treatment or results.
            </p>
            <ul className="mt-8 grid gap-4 sm:grid-cols-2">
              {DOCTOR_POINTS.map((point) => (
                <li key={point.title} className="flex items-center gap-3">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent/10 text-accent">
                    <point.icon className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-semibold text-foreground">{point.title}</span>
                </li>
              ))}
            </ul>
            <div className="mt-10">
              <Link
                to="/contact"
                className="group inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground shadow-lg shadow-accent/30 transition hover:scale-[1.02] hover:shadow-accent/50"
              >
                Consult with a Doctor
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>

          <div className="order-first mx-auto w-full max-w-md md:order-none">
            <div className="aspect-[4/3] overflow-hidden rounded-3xl shadow-2xl md:aspect-[4/5]">
              <img
                src={doctorImage}
                alt="Independent licensed doctor"
                loading="lazy"
                className="h-full w-full object-cover object-[50%_30%] md:object-center"
              />
            </div>
          </div>
        </div>
      </section> */}

      <section className="overflow-hidden bg-background">
        <div className="grid items-center gap-12 px-4 pb-20 sm:px-8 md:grid-cols-2 md:pt-20 lg:px-16 xl:px-24">
          <div className="relative">
            <div className="relative z-10 aspect-video w-full overflow-hidden rounded-3xl">
              <img
                src={researchHome}
                alt="ONYX research materials"
                className="h-full w-full object-cover shadow-2xl"
              />
            </div>
          </div>
          <div className="lg:pl-10">
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent">
              Research Focused
            </span>
            <h2 className="max-w-lg text-3xl font-black leading-tight text-foreground md:text-4xl lg:text-5xl">
              Research Materials &amp; Analytical Standards
            </h2>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-muted-foreground">
              Explore laboratory research materials supported by batch-level analytical testing
              and documentation. ONYX products are supplied exclusively for legitimate laboratory
              and scientific research.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/peptides"
                className="group inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground shadow-lg shadow-accent/30 transition hover:scale-[1.02] hover:shadow-accent/50"
              >
                Explore Research Materials
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-gradient-to-br from-primary to-[#0a1733] text-primary-foreground">
        <div
          aria-hidden
          className="pointer-events-none absolute -left-40 top-0 h-[30rem] w-[30rem] rounded-full bg-accent/20 blur-[160px]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -right-40 bottom-0 h-[30rem] w-[30rem] rounded-full bg-sky-500/10 blur-[160px]"
        />
        <div className="relative mx-auto max-w-7xl px-4 py-10 2xl:py-16">
          <div className="mb-10 text-center">
            <h2 className="text-3xl font-black tracking-tight md:text-5xl">
              Research <span className="text-white">Areas</span>
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-sm leading-relaxed opacity-70 md:text-base">
              Peptide research covers a broad range of laboratory and analytical applications.
              ONYX provides research materials for scientific investigations involving peptide
              identity, composition, analytical characteristics and laboratory methodologies.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-6 lg:grid-cols-3">
            {RESEARCH_AREAS.map((area) => (
              <div
                key={area.title}
                className="rounded-2xl border border-white/10 p-5 text-center md:p-6"
              >
                <area.icon className="mx-auto h-12 w-12 text-accent" />
                <h3 className="mt-4 text-lg font-bold">{area.title}</h3>
                <p className="mt-2 text-sm leading-relaxed opacity-70">{area.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="overflow-hidden bg-background">
        <div className="mx-auto grid max-w-7xl items-center gap-6 px-4 pb-1 pt-16 sm:px-8 md:grid-cols-2 md:pb-16 lg:px-16 xl:px-24">
          <div>
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent">
              Batch Verified
            </span>
            <h2 className="text-3xl font-black leading-tight text-foreground md:text-4xl lg:text-5xl">
              Quality &amp; Testing
            </h2>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Every ONYX Research batch is independently verified by third-party laboratories
              using HPLC and mass spectrometry, with a reported purity of at least 99%. A
              certificate of analysis accompanies each product line, documenting identity,
              purity and batch-specific testing data.
            </p>
            <Link
              to="/contact"
              className="group mt-7 inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground shadow-lg shadow-accent/30 transition hover:scale-[1.02] hover:shadow-accent/50"
            >
              Contact Us
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          <div className="relative z-10 aspect-[4/3] w-full overflow-hidden rounded-3xl">
            <img
              src={qualityTestingImage}
              alt="ONYX research material undergoing quality testing"
              className="h-full w-full object-cover shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Wholesale partnership */}
      <section className="bg-background">
        <div className="mx-auto max-w-7xl px-4 py-20">
          <div className="relative overflow-hidden rounded-3xl border bg-gradient-to-br from-secondary to-background p-2 shadow-sm md:px-14 md:py-10">
            <div
              aria-hidden
              className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-accent/10 blur-[130px]"
            />
            <div className="relative grid items-center gap-10 md:grid-cols-2 md:gap-14">
              <div>
                <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-accent backdrop-blur-sm">
                  <Handshake className="h-3.5 w-3.5" />
                  Wholesale Program
                </span>
                <h2 className="text-3xl font-black leading-tight tracking-tight md:text-4xl lg:text-5xl">
                  Research Supply Program
                </h2>
                <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground md:text-base">
                  Supply research materials to qualified laboratories, universities, research
                  organizations, and scientific businesses.
                </p>
                <Link
                  to="/wholesale-application"
                  className="group mt-8 inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground shadow-lg shadow-accent/30 transition hover:scale-[1.02] hover:shadow-accent/50"
                >
                  Apply for wholesale account
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                {[
                  {
                    icon: FlaskConical,
                    title: "Laboratory Supply",
                    body: "Bulk research-material supply for qualified organizations.",
                  },
                  {
                    icon: ClipboardCheck,
                    title: "Batch Documentation",
                    body: "Analytical documentation available for applicable materials.",
                  },
                  {
                    icon: Headset,
                    title: "Business Support",
                    body: "Dedicated support for approved research and laboratory accounts.",
                  },
                ].map((p) => (
                  <div
                    key={p.title}
                    className="flex h-full min-h-[180px] flex-col rounded-2xl border bg-card p-3 md:p-5"
                  >
                    <p.icon className="mb-3 h-7 w-7 text-accent" />
                    <h3 className="text-sm font-bold">{p.title}</h3>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{p.body}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter — full-bleed light band */}
      <section className="bg-secondary">
        <div className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-6 md:grid-cols-2 md:py-4">
          <div>
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-accent">
              Newsletter
            </span>
            <h2 className="text-2xl font-black tracking-tight text-foreground md:text-4xl">
              Stay informed
            </h2>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground md:text-base">
              Research insights, new product releases, and exclusive offers delivered straight to
              your inbox.
            </p>
          </div>
          <div className="md:w-full md:max-w-md md:justify-self-end">
            <form className="flex flex-col gap-3 sm:flex-row" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                required
                placeholder="Your email"
                className="flex-1 rounded-full border bg-background px-5 py-3.5 text-sm outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20"
              />
              <button className="group inline-flex items-center justify-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground shadow-lg shadow-accent/30 transition hover:scale-[1.02] hover:shadow-accent/50">
                Subscribe
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
            </form>
            <p className="mt-3 text-xs text-muted-foreground">
              No spam. Unsubscribe anytime. For research use only.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
